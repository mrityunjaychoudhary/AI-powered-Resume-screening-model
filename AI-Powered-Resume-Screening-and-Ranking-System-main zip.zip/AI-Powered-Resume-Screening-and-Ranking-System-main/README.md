An AI-Powered Resume Screening and Cadidate Ranking System using SBERT.
📚 Technologies Used
Python 3.x
Scikit-learn (TF-IDF)
Sentence-Transformers (SBERT)
Streamlit (for UI, optional)
